package lottery;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Count the occurrence of each lottery number
 */
public class LotteryCount {

	/**
	 * Mapper which extracts the lottery number and passes it to the Reducer with a single occurrence
	 */
	public static class LotteryMapper extends Mapper<Object, Text, IntWritable, IntWritable> {

		private final static IntWritable one = new IntWritable(1);

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			final String[] row = value.toString().split(",");
			final List<String> lotteryNumbersStr = new ArrayList<String>(Arrays.stream(row[1].split(" ")).toList());
			lotteryNumbersStr.add(row[2]);
			for (final String num : lotteryNumbersStr) {
				context.write(new IntWritable(Integer.parseInt(num)), one);
			}
		}
	}

	/**
	 * Reducer to sum up the occurrence
	 */
	public static class LotteryReducer extends Reducer<IntWritable,IntWritable,IntWritable,IntWritable> {

		public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
			int count = 0;
			for(final IntWritable val : values) {
				count+=val.get();
			}
			context.write(key, new IntWritable(count));
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		
		Job job = Job.getInstance(conf, "Lottery Count");
		job.setJarByClass(LotteryCount.class);
		job.setMapperClass(LotteryMapper.class);
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setCombinerClass(LotteryReducer.class); // combiner can be used since it's an associative operation defined in the reducer
		job.setReducerClass(LotteryReducer.class);
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
