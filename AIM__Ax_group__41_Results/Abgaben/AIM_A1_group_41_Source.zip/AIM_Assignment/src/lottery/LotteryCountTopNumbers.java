package lottery;

import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Return the lottery numbers sorted by their occurrence
 */
public class LotteryCountTopNumbers {
	public static class LotterySortedReducer extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {
		
		private final Map<Integer, Integer> countMap = new HashMap<>();
		
		public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
			int count = 0;
			for(final IntWritable val : values) {
				count+=val.get();
			}
			countMap.put(key.get(), count);
		}
		
		@Override
		protected void cleanup(Context context) throws IOException, InterruptedException {
			final List<Map.Entry<Integer, Integer>> list = new ArrayList<>(this.countMap.entrySet());
			list.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()) != 0 ? e2.getValue().compareTo(e1.getValue()) : e1.getKey().compareTo(e2.getKey()));
			
			for (final Map.Entry e : list) {
				context.write(new IntWritable((int) e.getKey()), new IntWritable((int) e.getValue()));
			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		
		Job job = Job.getInstance(conf, "Lottery Count");
		job.setJarByClass(LotteryCountTopNumbers.class);
		job.setMapperClass(LotteryCount.LotteryMapper.class);
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setCombinerClass(LotteryCount.LotteryReducer.class); // combiner can be used since it's an associative operation defined in the reducer
		job.setReducerClass(LotterySortedReducer.class);
		job.setNumReduceTasks(1); // enforce single reducer node to ensure global ordering
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(IntWritable.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
