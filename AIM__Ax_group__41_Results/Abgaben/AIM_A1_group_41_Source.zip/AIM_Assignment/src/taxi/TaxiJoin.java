package taxi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Reduce-side join between taxi trip data aggregates and fuel prices
 */
public class TaxiJoin {

    /**
     * Mapper which extracts the dropoff_date and taxi aggregates from task 2.2
     */
    public static class TaxiResultMapper extends Mapper<Object, Text, Text, Text> {

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            final String[] tokens = value.toString().split("\t");
            if (tokens.length >= 3) {
                context.write(new Text(tokens[0]), new Text("TAXI:" + tokens[1] + "," + tokens[2]));
            }
        }
    }

    /**
     * Mapper which extracts the businessday and buffalo_price from fuel prices
     */
    public static class FuelMapper extends Mapper<Object, Text, Text, Text> {

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            final String[] tokens = value.toString().split(",");
            if (tokens.length >= 5 && !tokens[0].equals("businessday")) {
                context.write(new Text(tokens[0]), new Text("FUEL:" + tokens[4]));
            }
        }
    }

    /**
     * Reducer to join datasets and calculate theoretical gross margin
     */
    public static class JoinReducer extends Reducer<Text, Text, Text, Text> {

        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            final List<String> taxiData = new ArrayList<>();
            String fuelPriceStr = null;

            for (final Text val : values) {
                final String valStr = val.toString();
                if (valStr.startsWith("TAXI:")) {
                    taxiData.add(valStr.substring(5));
                } else if (valStr.startsWith("FUEL:")) {
                    fuelPriceStr = valStr.substring(5);
                }
            }

            if (fuelPriceStr != null && !taxiData.isEmpty()) {
                try {
                    final double buffaloPrice = Double.parseDouble(fuelPriceStr);
                    for (final String taxi : taxiData) {
                        final String[] tokens = taxi.split(",");
                        final double distance = Double.parseDouble(tokens[0]);
                        final double earnings = Double.parseDouble(tokens[1]);
                        final double grossMargin = earnings - ((buffaloPrice * distance) / 21.3);
                        context.write(key, new Text(String.format("%.2f", grossMargin)));
                    }
                } catch (NumberFormatException e) {
                    // skip malformed numbers
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();

        Job job = Job.getInstance(conf, "Taxi Fuel Join");
        job.setJarByClass(TaxiJoin.class);
        job.setReducerClass(JoinReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, TaxiResultMapper.class);
        MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class, FuelMapper.class);
        FileOutputFormat.setOutputPath(job, new Path(args[2]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}