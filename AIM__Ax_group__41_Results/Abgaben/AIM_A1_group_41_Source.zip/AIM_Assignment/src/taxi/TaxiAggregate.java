package taxi;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * Aggregates distance and earnings per dropoff_date
 */
public class TaxiAggregate {

    /**
     * Mapper extracts dropoff_date (Index 1) as key, 
     * and combines distance (Index 6) and earnings (Index 7) as value.
     */
    public static class TaxiMapper extends Mapper<Object, Text, Text, Text> {

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // CSV-Zeile splitten
            String[] row = value.toString().split(",");
            
            // Absicherung gegen fehlerhafte Zeilen oder Header
            if (row.length >= 8 && !row[1].equals("dropoff_date")) {
                String dropoffDate = row[1]; // dropoff_date ist das zweite Element
                String distance = row[6];    // distance ist das siebte Element
                String earnings = row[7];    // earnings ist das achte Element
                
                // Wir übergeben "distance,earnings" als kombinierten String
                context.write(new Text(dropoffDate), new Text(distance + "," + earnings));
            }
        }
    }

    /**
     * Reducer sums up distances and earnings for each unique dropoff_date
     */
    public static class TaxiReducer extends Reducer<Text, Text, Text, Text> {

        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            double totalDistance = 0.0;
            double totalEarnings = 0.0;

            for (Text val : values) {
                String[] tokens = val.toString().split(",");
                if (tokens.length == 2) {
                    try {
                        totalDistance += Double.parseDouble(tokens[0]);
                        totalEarnings += Double.parseDouble(tokens[1]);
                    } catch (NumberFormatException e) {
                        // Fehlerhafte Zahlenformate überspringen
                    }
                }
            }
            
            // Formatierung der Ausgabe: "Gesamtdistanz\tGesamteinnahmen"
            String resultValue = String.format("%.2f\t%.2f", totalDistance, totalEarnings);
            context.write(key, new Text(resultValue));
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();

        Job job = Job.getInstance(conf, "Taxi Aggregate");
        job.setJarByClass(TaxiAggregate.class);
        
        job.setMapperClass(TaxiMapper.class);
        job.setReducerClass(TaxiReducer.class);

        // Map- und Reduce-Ausgabetypen festlegen
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        // Wichtig: Keinen Combiner nutzen, da das String-Format "dist,earn" 
        // im Combiner mathematisch so nicht direkt addiert werden kann.

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}